(function(module) {
	'use strict';
	module.controller('formulas', function($scope) {

	})
})(angular.module('iot.controllers'))