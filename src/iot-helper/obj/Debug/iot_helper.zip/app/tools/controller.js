(function(module){
	'use strict';
	module.controller('tools', function($scope) {
	})
})(angular.module('iot.controllers'))